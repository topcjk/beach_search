
package miniProject;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class review_main extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea;
	private JRadioButton rb1_1,rb1_2,rb1_3,rb2_1,rb2_2,rb2_3,rb3_1,rb3_2,rb3_3;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					review_main frame = new review_main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	/**
	 * Create the frame.
	 */
	public review_main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 471, 546);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JButton btnNewButton = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				dispose();
				setVisible(false);
				new gangwon().setVisible(true);
			}
		});
		
		
		btnNewButton.setBounds(174, 474, 97, 23);
		contentPane.add(btnNewButton);
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(29, 150, 390, 154);
		contentPane.add(scrollPane_1);
		
		textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);
		textArea.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uB9AC\uBDF0 \uC791\uC131");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(158, 33, 196, 51);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("���ǽü� :");
		lblNewLabel_1.setBounds(29, 330, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC774\uB3D9\uC218\uB2E8 :");
		lblNewLabel_1_1.setBounds(29, 368, 57, 15);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("\uD63C\uC7A1\uB3C4 :");
		lblNewLabel_1_2.setBounds(29, 403, 57, 15);
		contentPane.add(lblNewLabel_1_2);
		
//		JRadioButton rb1_1 = new JRadioButton("\uD3B8\uC758\uC810");
//		rb1_1.setBounds(101, 326, 81, 23);
//		contentPane.add(rb1_1);
//	
//		
//		JRadioButton rb1_2 = new JRadioButton("\uC0E4\uC6CC\uC7A5");
//		rb1_2.setBounds(199, 326, 81, 23);
//		contentPane.add(rb1_2);
//		
//		JRadioButton rb1_3 = new JRadioButton("\uD30C\uB77C\uC194");
//		rb1_3.setBounds(311, 326, 81, 23);
//		contentPane.add(rb1_3);
		

		JRadioButton rb2_1 = new JRadioButton("\uC9C0\uD558\uCCA0");
		rb2_1.setBounds(100, 362, 81, 23);
		contentPane.add(rb2_1);
		rb2_1.setText("����ö");
		
		
		JRadioButton rb2_2 = new JRadioButton("\uBC84\uC2A4");
		rb2_2.setBounds(198, 362, 81, 23);
		contentPane.add(rb2_2);
		
		JRadioButton rb2_3 = new JRadioButton("\uC790\uCC28");
		rb2_3.setBounds(310, 362, 81, 23);
		contentPane.add(rb2_3);
		
		JRadioButton rb3_1 = new JRadioButton("\uC6D0\uD65C");
		
		rb3_1.setBounds(101, 399, 81, 23);
		contentPane.add(rb3_1);
		
		JRadioButton rb3_2 = new JRadioButton("\uBCF4\uD1B5");
		rb3_2.setBounds(199, 399, 81, 23);
		contentPane.add(rb3_2);
		
		JRadioButton rb3_3 = new JRadioButton("\uD63C\uC7A1");
		rb3_3.setBounds(311, 399, 81, 23);
		contentPane.add(rb3_3);
		
		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(rb2_1);
		bg2.add(rb2_2);
		bg2.add(rb2_3);
		ButtonGroup bg3 = new ButtonGroup();
		bg3.add(rb3_1);
		bg3.add(rb3_2);
		bg3.add(rb3_3);
		
		
		JButton btnNewButton_1 = new JButton("\uC791\uC131\uC644\uB8CC");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String selTrans = "";	// ���õ� ������� ���� ��
				String selCong = "";	// ���õ� ȥ�⵵ ���� ��
				String rv = textArea.getText();
				
				Enumeration<AbstractButton> enums = bg2.getElements();
				while(enums.hasMoreElements()){ //hasMoreElements() Enum�� �� ���� ��ü�� �ִ���
				                                      // üũ�Ѵ�. ������ false ��ȯ
					AbstractButton ab = enums.nextElement(); //���׸����� AbstractButton �̴ϱ� �翬��             
													// AbstractButton���� �޾ƾ���
				    JRadioButton jb = (JRadioButton)ab;         
					    	//����ȯ. ���� ���ٰ� ������ ���ļ� �ٷ� ����ȯ �ؼ� �޾Ƶ� �ȴ�.

				    if(jb.isSelected()) {         //�޾Ƴ� ������ư�� üũ ���¸� Ȯ���Ѵ�. üũ�Ǿ������ true ��ȯ.
				    	selTrans = jb.getText(); //getText() �޼ҵ�� ���ڿ� �޾Ƴ���.
				    	System.out.println(selTrans);
				    	System.out.println(selTrans.getClass().getName());
				    }
				 }
				
				Enumeration<AbstractButton> enums2 = bg3.getElements();
				while(enums2.hasMoreElements()){ //hasMoreElements() Enum�� �� ���� ��ü�� �ִ���
				                                      // üũ�Ѵ�. ������ false ��ȯ
					AbstractButton ab2 = enums2.nextElement(); //���׸����� AbstractButton �̴ϱ� �翬��             
													// AbstractButton���� �޾ƾ���
				    JRadioButton jb2 = (JRadioButton)ab2;         
					    	//����ȯ. ���� ���ٰ� ������ ���ļ� �ٷ� ����ȯ �ؼ� �޾Ƶ� �ȴ�.

				    if(jb2.isSelected()) {         //�޾Ƴ� ������ư�� üũ ���¸� Ȯ���Ѵ�. üũ�Ǿ������ true ��ȯ.
				    	selTrans = jb2.getText(); //getText() �޼ҵ�� ���ڿ� �޾Ƴ���.
				    	System.out.println(selCong);
				    	System.out.println(selCong.getClass().getName());
				    }
				 }
	
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				Connection conn = null;
				try {
					conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe","c##bada","bada");
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				if(conn==null) 	{System.out.println("DB���ӿ� ����");}
				else			{System.out.println("DB���� ����");}
				
				
				//String amenity = textArea.getText();
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				

				String sql="insert into badareview (review, transport, congestion) "
						+ "values(?,?,?)";
				
				//	�̸� ������ ����� ���´�.
				
				try {
					System.out.println(selTrans);
					System.out.println(selCong);
					
					pstmt = conn.prepareStatement(sql);
					pstmt.setNString(1, rv);
					pstmt.setNString(2, selTrans);
					pstmt.setNString(3, selCong);
					rs = pstmt.executeQuery();
					System.out.println("DB���� ����");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				dispose();
				setVisible(false);
				new review_db().setVisible(true);
				
			}
			
		});
		
		btnNewButton_1.setBounds(174, 441, 97, 23);
		contentPane.add(btnNewButton_1);
		
		 
	    	
		
	    	
	    }
		
		
	}

