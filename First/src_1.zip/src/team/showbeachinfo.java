package team;

import java.awt.EventQueue;
import java.sql.Array;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class showbeachinfo extends JFrame {
	String searchbadaname="";
	private JPanel contentPane;
	ArrayList<getdata2> getreviewdata;
	String a,b,c,e;
	int d;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					showbeachinfo frame = new showbeachinfo("");
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public showbeachinfo(String badaname) throws ClassNotFoundException, SQLException {
		
		telldata tda=new telldata();
		searchbadaname=badaname;
		getreviewdata=tda.getallreviewdata(searchbadaname);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(600, 300, 763, 489);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(51, 40, 660, 295);
		getContentPane().add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);//�����Ұ�
		
         
		System.out.println("���� ������");
		
		
		for(getdata2 imsi:getreviewdata) {
			a=imsi.getFacility();
			b=imsi.getCongestion();
			c=imsi.getTransport();
			d=imsi.getRate();
			e=imsi.getReview();
			
			textArea.append("���ǽü�:"+a+"\t  ȥ�⵵:"+b+
					"\t  ����ü�:"+c+"\t  ����"+d+"\t  ����:"+e+"\n");
			
			System.out.print("���ǽü�:"+a+"\t  ȥ�⵵:"+b+
					"\t  ����ü�:"+c+"\t  ����"+d+"\t  ����:"+e);
			
		}
		if(getreviewdata.size()==0) {
			textArea.append("���䰡 �������� �ʽ��ϴ�");
		}
		System.out.println(getreviewdata);
		setVisible(true);
		
	}
	
}
