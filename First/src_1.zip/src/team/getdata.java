package team;

public class getdata {
	
	private String name;
	
	
	public getdata() {}
	public getdata(String name) {
		super();
		this.name = name;
		
	}
	
	public String getName() {
		return name;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	
}
