package team;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import team.region.*;

import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import team.telldata;


public class beachmaintest1 extends JFrame {
	
	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					beachmaintest1 frame = new beachmaintest1();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public beachmaintest1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 890, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton northjeonla = new JButton("\uC804\uB77C\uBD81\uB3C4");
		
		northjeonla.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("����ϵ�");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		northjeonla.setBounds(260, 60, 132, 127);
		contentPane.add(northjeonla);
		
		JButton southjeonra = new JButton("\uC804\uB77C\uB0A8\uB3C4");
		southjeonra.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("���󳲵�");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		southjeonra.setBounds(260, 184, 132, 127);
		contentPane.add(southjeonra);
		
		JButton southchungcheong = new JButton("\uCDA9\uCCAD\uB0A8\uB3C4");
		southchungcheong.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("��û����");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		southchungcheong.setBounds(129, 60, 132, 127);
		contentPane.add(southchungcheong);
		
		
		
		
		JButton gwangwon = new JButton("\uAC15\uC6D0\uB3C4");
		gwangwon.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("������");
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		gwangwon.setBounds(521, 184, 132, 127);
		contentPane.add(gwangwon);
		
		JButton northgyongsang = new JButton("\uACBD\uC0C1\uBD81\uB3C4");
		northgyongsang.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("���ϵ�");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		northgyongsang.setBounds(390, 60, 132, 127);
		contentPane.add(northgyongsang);
		
		
		JButton southgyongsang = new JButton("\uACBD\uC0C1\uB0A8\uB3C4");
		southgyongsang.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("��󳲵�");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		southgyongsang.setBounds(390, 184, 132, 127);
		contentPane.add(southgyongsang);
		
		JButton jeju = new JButton("\uC81C\uC8FC\uB3C4");
		jeju.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("���ֵ�");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		jeju.setBounds(521, 60, 132, 127);
		contentPane.add(jeju);
		
		JButton exit = new JButton("\uC885\uB8CC");
		exit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		exit.setBounds(370, 391, 97, 23);
		contentPane.add(exit);
		
		JButton gyeongi = new JButton("\uACBD\uAE30\uB3C4");
		gyeongi.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				try {
					new showbeachlist("��⵵");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		gyeongi.setBounds(129, 184, 132, 127);
		contentPane.add(gyeongi);
		
		
	}
}
