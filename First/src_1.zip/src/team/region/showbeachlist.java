package team.region;

import team.*;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class showbeachlist extends JFrame {
	public String beachnames[]= {};
	DefaultListModel model;
	private JPanel contentPane;
	private JTextField searchtext;
	ArrayList<getdata> str;
	Vector vec;
	String siname="";
	String final_beachname="";
	/**
	 * Launch the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		//seoul s1=new seoul(" ");
		
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public showbeachlist(String location_name) throws ClassNotFoundException, SQLException {
		telldata tda=new telldata();
		siname=location_name;
		int beachcount=tda.getbeachnum(siname);
		
		ArrayList<getdata> str= tda.getbeachs(siname);
		String beachnames[]=new String[beachcount];
		int x=0;
		for(getdata imsi:str) {
			
			beachnames[x]=(imsi.getName());
//			System.out.println(imsi.getName());
//			System.out.println(x+beachnames[x]);
			x++;
		}
		for(int i=0;i<beachcount;i++) {
			System.out.println(beachnames[i]);
		}
		System.out.println("������� �˻���");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(600, 300, 763, 489);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		searchtext = new JTextField();
		searchtext.setBounds(72, 35, 116, 21);
		contentPane.add(searchtext);
		searchtext.setColumns(10);
		
		

		
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(72, 79, 449, 301);
		contentPane.add(scrollPane);
		
		JList list = new JList(beachnames);
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				final_beachname=(String)list.getSelectedValue();
				System.out.println("���õ�:"+final_beachname);
				
			}
		});
		scrollPane.setViewportView(list);
		
		
		JButton beachsearch = new JButton("\uAC80\uC0C9\uD558\uAE30");
		beachsearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String searchabout=searchtext.getText();
				try {
					System.out.println("�����Է���");
					
					String siname=location_name;
					
					ArrayList<getdata> str= tda.searchsometext(location_name, searchabout);
					int searchcount=tda.searchedbeachsnumber(location_name,searchabout);
					String searchedbeachnames[]=new String[searchcount];
					int x=0;
					for(getdata imsi:str) {
						
						searchedbeachnames[x]=(imsi.getName());
						x++;
					}
					for(int i=0;i<searchcount;i++) {
						System.out.println(searchedbeachnames[i]);
					}
					JList list = new JList(searchedbeachnames);
					list.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							final_beachname=(String) list.getSelectedValue();
							System.out.println("���õ�:"+final_beachname);
						}
					});
					scrollPane.setViewportView(list);					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		beachsearch.setBounds(230, 34, 97, 23);
		contentPane.add(beachsearch);
		
		JButton gobackbtn = new JButton("<----\uC774\uC804");
		gobackbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				try {
					beachmaintest1 frame = new beachmaintest1();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				}
				catch(Exception e1){
					e1.printStackTrace();
				}
			}
		});
		gobackbtn.setBounds(71, 396, 97, 23);
		contentPane.add(gobackbtn);
		
		JLabel doe = new JLabel(location_name);
		doe.setBounds(72, 10, 57, 15);
		contentPane.add(doe);
		
		
		JButton showbeach = new JButton("\uB9AC\uBDF0\uBCF4\uAE30");//���亸��
		showbeach.setBounds(573, 396, 97, 23);
		contentPane.add(showbeach);
		
		showbeach.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(list.getSelectedValue()!=null) {
					//System.out.println("�����"+list.getSelectedValue());
					dispose();
					try {
						new showbeachinfo(final_beachname);
						
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				
			}
		});
		setVisible(true);
		
		
	}
}
