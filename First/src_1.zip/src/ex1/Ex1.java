package ex1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

public class Ex1 extends JFrame {
	
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ex1 frame = new Ex1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ex1() {
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 515, 377);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JRadioButton rb_1 = new JRadioButton("\uC0AC\uACFC");
		rb_1.setBounds(32, 187, 71, 23);
		contentPane.add(rb_1);
		
		JRadioButton rb_2 = new JRadioButton("\uBC30");
		rb_2.setBounds(129, 187, 71, 23);
		contentPane.add(rb_2);
		
		JRadioButton rb_3 = new JRadioButton("\uADE4");
		rb_3.setBounds(224, 187, 50, 23);
		contentPane.add(rb_3);
		
		ButtonGroup  gr = new ButtonGroup();
		
		gr.add(rb_1);
		gr.add(rb_2);
		gr.add(rb_3);
		
		
		
		
		JButton bt1 = new JButton("\uC800\uC7A5");
		bt1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String selJong = "";
				
				
				Enumeration<AbstractButton> enums = gr.getElements();
				while(enums.hasMoreElements()){ //hasMoreElements() Enum�� �� ���� ��ü�� �ִ���

				                                                   //  üũ�Ѵ�. ������ false ��ȯ
					AbstractButton ab = enums.nextElement(); //���׸����� AbstractButton �̴ϱ� �翬��             

				                                                             //     AbstractButton���� �޾ƾ���
				    JRadioButton jb = (JRadioButton)ab;         
				    
				    
				    //����ȯ. ���� ���ٰ� ������ ���ļ� �ٷ� ����ȯ �ؼ� �޾Ƶ� �ȴ�.


				    if(jb.isSelected()) {         //�޾Ƴ� ������ư�� üũ ���¸� Ȯ���Ѵ�. üũ�Ǿ������ true ��ȯ.
				    	selJong = jb.getText(); //getText() �޼ҵ�� ���ڿ� �޾Ƴ���.
				    	System.out.println(selJong);
				    	System.out.println(selJong.getClass().getName());
				    }
				 }	
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				Connection conn = null;
				try {
					conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe","c##bada","bada");
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				if(conn==null) 	System.out.println("DB���ӿ� ����");
				else			System.out.println("DB���� ����");
				
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				
				String sql="INSERT INTO gwail VALUES(?)";
				
				try {
					pstmt = conn.prepareStatement(sql);
					pstmt.setNString(1, selJong);
					rs = pstmt.executeQuery();
					System.out.println("DB���� ����");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				

			}
		});
		bt1.setBounds(275, 279, 97, 23);
		contentPane.add(bt1);
		
		
	}
	
	
}
